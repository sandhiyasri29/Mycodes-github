package com.example.SandhiyaDBB.RepoDb;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SandhiyaDBB.Entity.Entitydb;

public interface Repodb extends JpaRepository<Entitydb,Integer>{

}
