package com.example.SandhiyaDBB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SandhiyaDbbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SandhiyaDbbApplication.class, args);
	}

}
